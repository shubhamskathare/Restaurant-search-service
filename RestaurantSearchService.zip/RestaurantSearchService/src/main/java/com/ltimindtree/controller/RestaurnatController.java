package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.Restaurant;
import com.ltimindtree.service.impl.RestaurantServiceImpl;

@RestController
@RequestMapping("/restaurants")
public class RestaurnatController {
	
	@Autowired
	private RestaurantServiceImpl restaurantImpl;
	
	Map<String, Object> response;

	//localhost:8081/restaurants/createRestaurant
	@PostMapping("/createRestaurant")
	public ResponseEntity<Map<String, Object>> createRestaurant(@RequestBody Restaurant restaurant){
		response=new HashMap<String, Object>();
		response.put("message", "restaurants added successfully");
		response.put("status", HttpStatus.OK);
		response.put("body", restaurantImpl.createRestaurant(restaurant));
		response.put("error", false);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		
	}
	
	
			//localhost:8081/restaurants/getRestaurantsByName/
			@GetMapping("/getRestaurantsByName/{name}")
			public ResponseEntity<Map<String, Object>> getRestaurantByName(@PathVariable String name){
				
				response=new HashMap<String,Object>();
				response.put("message", "restaurants found by name");
				response.put("status", HttpStatus.OK);
				response.put("body", restaurantImpl.getRestaurantByName(name));
				response.put("error", false);
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
				
			}
			
			
			//localhost:8081/restaurants/getResturantsByLocation/
			@GetMapping("/getResturantsByLocation/{location}")
			public ResponseEntity<Map<String, Object>> getRestaurentByLocation(@PathVariable String location){
				
				response=new HashMap<String,Object>();
				response.put("message", "restaurant found by location");
				response.put("status", HttpStatus.OK);
				response.put("body", restaurantImpl.getRestaurantByLocation(location));
				response.put("error",false);
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
			}
			
			
			//localhost:8081/restaurants/getRestaurantByDistance/
			@GetMapping("/getRestaurantByDistance/{distance}")
			public ResponseEntity<Map<String, Object>> getRestaurantByDistance(@PathVariable int distance){
				response=new HashMap<String,Object>();
				response.put("message", "restaurant found by distance");
				response.put("status",HttpStatus.OK);
				response.put("body", restaurantImpl.getRestaurantByDistance(distance));
				response.put("error",false);
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
				
			}
			
			
			//localhost:8081/restaurants/getRestaurantByCuisine/
			@GetMapping("/getRestaurantByCuisine/{cuisine}")
			public ResponseEntity<Map<String, Object>> getRestaurantByCuisine(@PathVariable String cuisine){
				response=new HashMap<String,Object>();
				response.put("message", "restaurant found by cuisine");
				response.put("status",HttpStatus.OK);
				response.put("body", restaurantImpl.getRestaurantByCuisine(cuisine));
				response.put("error",false);
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
				
			}
			
			
			//localhost:8081/restaurants/getRestaurantByBudget/
			@GetMapping("/getRestaurantByBudget/{budget}")
			public ResponseEntity<Map<String, Object>> getRestaurantByBudget(@PathVariable int budget){
				response=new HashMap<String,Object>();
				response.put("message", "restaurant found by budget");
				response.put("status",HttpStatus.OK);
				response.put("body", restaurantImpl.getRestaurantByBudget(budget));
				response.put("error",false);
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
				
			}
			//localhost:8081/restaurants/getRestaurantByRating/
			@GetMapping("/getRestaurantByRating/{rating}")
			public ResponseEntity<Map<String, Object>> getRestaurantByRatings(@PathVariable double rating){
				
				response=new HashMap<String,Object>();
				response.put("message", "restaurant found by rating");
				response.put("status",HttpStatus.OK);
				response.put("body", restaurantImpl.getRestaurantByRatings(rating));
				response.put("error",false);
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
				
			}
			

	
	
	

}
