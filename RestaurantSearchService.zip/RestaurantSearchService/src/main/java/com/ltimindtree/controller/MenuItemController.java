package com.ltimindtree.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ltimindtree.entity.MenuItem;
import com.ltimindtree.service.impl.MenuItemServiceImpl;

@RestController
@RequestMapping("/menuItems")
public class MenuItemController {
	
	@Autowired
	private MenuItemServiceImpl menuServiceImpl;
	
    private Map<String, Object> response;
	
	
	//localhost:8081/menuItems/createRestaurantMenu
		@PostMapping("/createRestaurantMenu")
		public ResponseEntity<Map<String, Object>> createRestaurantMean(@RequestBody MenuItem menu){
			
			response=new HashMap<String,Object>();
			response.put("message", "restaurant added successfully");
			response.put("status",HttpStatus.OK);
			response.put("body", menuServiceImpl.createRestaurantMenu(menu));
			response.put("error",false);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
			
		}
		
		
		//localhost:8081/menuItems/findbyname/
		@GetMapping("/findbyname/{name}")
		public ResponseEntity<Map<String, Object>> getByname(@PathVariable String name){
			
			response=new HashMap<String,Object>();
			response.put("message", "restaurantmenu list by name");
			response.put("status",HttpStatus.OK);
			response.put("body", menuServiceImpl.findByName(name));
			response.put("error",false);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
			
		}
		
		
		//localhost:8081/menuItems/findAllMenusByRestaurantId/
		@GetMapping("/findAllMenusByRestaurantId/{restaurantId}")
		public ResponseEntity<Map<String, Object>> getAllMenusByRestaurantId(@PathVariable String restaurantId){
			
			response=new HashMap<String,Object>();
			response.put("message", "restaurantmenu list by restuarantid");
			response.put("status",HttpStatus.OK);
			response.put("body", menuServiceImpl.findAllMenusByRestaurantId(restaurantId));
			response.put("error",false);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
			
		}
		
		
		//localhost:8081/menuItems/findAllMenusByRestaurantIdAndName/
		@GetMapping("/findAllMenusByRestaurantIdAndName/{restaurantId}/{name}")
		public ResponseEntity<Map<String, Object>> getAllRestaurantByIdAndName(@PathVariable String restaurantId,
				@PathVariable String name){
			
			response=new HashMap<String,Object>();
			response.put("message", "restaurantmenu list by restuarantid and name");
			response.put("status",HttpStatus.OK);
			response.put("body", menuServiceImpl.findAllByRestaurantIdAndName(restaurantId, name));
			response.put("error",false);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
			
		}

		
		
		

}
