package com.ltimindtree.service.impl;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ltimindtree.entity.Restaurant;
import com.ltimindtree.exception.ResourceNotFoundException;
import com.ltimindtree.repository.RestaurantRepository;
import com.ltimindtree.service.RestaurantService;

@Service
public class RestaurantServiceImpl implements RestaurantService{
	
	@Autowired
	private RestaurantRepository restaurantRepository;

	@Override
	public Restaurant createRestaurant(Restaurant restaurant) {
		// TODO Auto-generated method stub
		return restaurantRepository.save(restaurant);
	}

	@Override
	public List<Restaurant> getRestaurantByName(String name){
		// TODO Auto-generated method stub
		return restaurantRepository.findByName(name);
	}

	@Override
	public List<Restaurant> getRestaurantByLocation(String location) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByLocation(location);
	}

	@Override
	public List<Restaurant> getRestaurantByDistance(int distance) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByDistance(distance);
	}

	@Override
	public List<Restaurant> getRestaurantByCuisine(String cuisine) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByCuisine(cuisine);
	}

	@Override
	public List<Restaurant> getRestaurantByBudget(int budget) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByBudget(budget);
	}

	@Override
	public List<Restaurant> getRestaurantByRatings(double rating) {
		// TODO Auto-generated method stub
		return restaurantRepository.findByRatings(rating);
	}

	

}
